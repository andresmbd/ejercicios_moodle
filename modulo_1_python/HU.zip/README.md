[Ver diagrama](diagramadeflujo.pdf)
